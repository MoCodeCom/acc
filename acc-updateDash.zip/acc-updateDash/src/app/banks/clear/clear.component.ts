import { Component } from '@angular/core';

@Component({
  selector: 'app-clear',
  templateUrl: './clear.component.html',
  styleUrl: './clear.component.css'
})
export class ClearComponent {

}
