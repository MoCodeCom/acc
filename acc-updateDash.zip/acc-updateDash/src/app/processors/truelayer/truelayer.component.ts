import { Component } from '@angular/core';

@Component({
  selector: 'app-truelayer',
  templateUrl: './truelayer.component.html',
  styleUrl: './truelayer.component.css'
})
export class TruelayerComponent {

}
