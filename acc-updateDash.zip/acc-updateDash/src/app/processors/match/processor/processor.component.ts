import { HttpClient } from '@angular/common/http';
import { Component, Input, OnInit, input } from '@angular/core';
import { ProcessorsService } from '../../processors.service';

@Component({
  selector: 'app-processor',
  templateUrl: './processor.component.html',
  styleUrl: './processor.component.css'
})
export class ProcessorComponent implements OnInit{
  constructor(
    private http:HttpClient,
    private serviceProcessor:ProcessorsService,
  ){}


  ngOnInit(): void {
    this.getReconData();
  }
/*----------------------- reconciliation-----------------------------*/
reconProcessorData:any[] =[];
reconData:any[] = [];
reconProcessorsTblData:any[] = [];
countProcessorData = 0;
//-------------------- Pagenation for processors table------------------//
POSTS2:any[]=null;
pageProcessor:number = 1;
countProcessor:number=0;
tableSizeProcessor:number=10;


//-------------- Table pagination -------------------//


onTableDataChangeProcessor(event:any):void{
  this.tableSizeProcessor =10;
  this.pageProcessor = event;
}

  async onMatch_credorex(id){

    await this.http.delete(`http://localhost:9000/deleterowreconcredorex/${id}`).subscribe(result =>{

    });
    setTimeout(() => {
      window.location.reload();
    }, 900);

  }

  //To get data from reconcilation database about processor table
  async getReconData(){
		//this.reconSystemTblData = [];
		this.reconProcessorsTblData = [];

		this.reconData = [];
		await this.http.get('http://localhost:9000/getreconcredorex').subscribe(result =>{
				this.reconData = result['data'][0];
				for(let i = 0;i<this.reconData.length; i++){
					if(this.reconData[i]["ID_processor"] != null){
						this.reconProcessorsTblData.push(this.reconData[i]);
						this.countProcessorData++;
            //this._InputCountProcessor++;
					}
				}
			});
      //this._InputCountProcessor = this.countProcessorData;
      this.serviceProcessor.countProcessor(this.countProcessorData);
			this.POSTS2 = this.reconProcessorsTblData;


	}
}
