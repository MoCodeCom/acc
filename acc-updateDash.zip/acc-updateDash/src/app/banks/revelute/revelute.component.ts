import { Component } from '@angular/core';

@Component({
  selector: 'app-revelute',
  templateUrl: './revelute.component.html',
  styleUrl: './revelute.component.css'
})
export class ReveluteComponent {

}
