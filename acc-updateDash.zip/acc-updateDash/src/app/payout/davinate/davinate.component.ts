import { Component } from '@angular/core';

@Component({
  selector: 'app-davinate',
  templateUrl: './davinate.component.html',
  styleUrl: './davinate.component.css'
})
export class DavinateComponent {

}
