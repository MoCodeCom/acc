import { Component } from '@angular/core';

@Component({
  selector: 'app-santander',
  templateUrl: './santander.component.html',
  styleUrl: './santander.component.css'
})
export class SantanderComponent {

}
