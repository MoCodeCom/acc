import { Component } from '@angular/core';

@Component({
  selector: 'app-paysafe-old',
  templateUrl: './paysafe-old.component.html',
  styleUrl: './paysafe-old.component.css'
})
export class PaysafeOldComponent {

}
