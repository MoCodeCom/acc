import { Component } from '@angular/core';

@Component({
  selector: 'app-mano',
  templateUrl: './mano.component.html',
  styleUrl: './mano.component.css'
})
export class ManoComponent {

}
