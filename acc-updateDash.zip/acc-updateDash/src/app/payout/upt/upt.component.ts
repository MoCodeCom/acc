import { Component } from '@angular/core';

@Component({
  selector: 'app-upt',
  templateUrl: './upt.component.html',
  styleUrl: './upt.component.css'
})
export class UptComponent {

}
