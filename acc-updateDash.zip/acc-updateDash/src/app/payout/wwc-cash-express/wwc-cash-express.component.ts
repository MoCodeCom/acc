import { Component } from '@angular/core';

@Component({
  selector: 'app-wwc-cash-express',
  templateUrl: './wwc-cash-express.component.html',
  styleUrl: './wwc-cash-express.component.css'
})
export class WwcCashExpressComponent {

}
