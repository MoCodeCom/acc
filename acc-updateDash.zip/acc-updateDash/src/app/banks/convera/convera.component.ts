import { Component } from '@angular/core';

@Component({
  selector: 'app-convera',
  templateUrl: './convera.component.html',
  styleUrl: './convera.component.css'
})
export class ConveraComponent {

}
