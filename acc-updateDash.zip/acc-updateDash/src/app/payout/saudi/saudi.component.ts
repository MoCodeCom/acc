import { Component } from '@angular/core';

@Component({
  selector: 'app-saudi',
  templateUrl: './saudi.component.html',
  styleUrl: './saudi.component.css'
})
export class SaudiComponent {

}
