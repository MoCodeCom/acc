import { Component } from '@angular/core';

@Component({
  selector: 'app-aktif',
  templateUrl: './aktif.component.html',
  styleUrl: './aktif.component.css'
})
export class AktifComponent {

}
