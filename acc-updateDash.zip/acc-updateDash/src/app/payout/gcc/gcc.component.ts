import { Component } from '@angular/core';

@Component({
  selector: 'app-gcc',
  templateUrl: './gcc.component.html',
  styleUrl: './gcc.component.css'
})
export class GccComponent {

}
